

import openai

# OpenAI API key
openai.api_key = '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'

def check_statement_with_gpt(statement):
    prompt = f"Check if the following statement is true or false:\n\n{statement}"
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": prompt},
        ],
        max_tokens=50,
        temperature=0.0,
    )
    return response['choices'][0]['message']['content'].strip()


